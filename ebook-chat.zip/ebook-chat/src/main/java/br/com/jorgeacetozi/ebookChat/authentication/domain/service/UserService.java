package br.com.jorgeacetozi.ebookChat.authentication.domain.service;

import br.com.jorgeacetozi.ebookChat.authentication.domain.model.User;

public interface UserService {

	User createUser(User user);
}
